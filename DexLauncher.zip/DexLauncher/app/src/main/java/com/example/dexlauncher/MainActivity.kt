package com.example.dexlauncher

import android.app.Activity
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

// ---------------------------------------------------------------------------------------------
// DeX-style launcher: desktop icons, taskbar, start menu, system tray and windowed app launching.
// Pure framework code (no AndroidX), UI is built in code so the project stays small.
// ---------------------------------------------------------------------------------------------

private val ACCENT = 0xFF4F8CFF.toInt()
private val TASKBAR_BG = 0xE61A1D27.toInt()
private val PANEL_BG = 0xF2202432.toInt()
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

data class AppInfo(val label: String, val pkg: String, val icon: Drawable)

class MainActivity : Activity() {

    companion object {
        // Kept outside the activity so they survive recreation (rotation, display change).
        private val recent = ArrayList<String>()
        private var windowCounter = 0

        private const val KEY_DESKTOP = "desktop"
        private const val KEY_TASKBAR = "taskbar"
        private const val KEY_WINDOWED = "windowed"
    }

    private val prefs by lazy { getSharedPreferences("dex_launcher", MODE_PRIVATE) }

    private var apps: List<AppInfo> = emptyList()
    private var appsByPkg: Map<String, AppInfo> = emptyMap()

    private lateinit var desktop: DesktopGrid
    private lateinit var taskbarApps: LinearLayout
    private lateinit var startScrim: FrameLayout
    private lateinit var searchBox: EditText
    private lateinit var appAdapter: AppAdapter
    private lateinit var batteryText: TextView
    private lateinit var netText: TextView
    private lateinit var contextAnchor: View

    private var taskbarHeight = 0
    private var compact = false
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    // ----------------------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        taskbarHeight = dp(56)
        compact = resources.configuration.screenWidthDp < 600
        setContentView(buildUi())
        loadApps()
    }

    override fun onStart() {
        super.onStart()

        registerSystemReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        })

        registerSystemReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.let { batteryReceiver.onReceive(this, it) }

        try {
            connectivity().registerDefaultNetworkCallback(netCallback)
        } catch (e: Exception) {
            netText.text = ""
        }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) { }
        try { connectivity().unregisterNetworkCallback(netCallback) } catch (e: Exception) { }
        closeStart()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Pressing Home while already on the desktop closes the start menu.
        closeStart()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher never exits on Back; it only closes the start menu.
        if (startScrim.visibility == View.VISIBLE) closeStart()
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        // Windows/Meta key opens the start menu (hardware keyboard on DeX / external display).
        if (keyCode == KeyEvent.KEYCODE_META_LEFT || keyCode == KeyEvent.KEYCODE_META_RIGHT) {
            toggleStart()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_ESCAPE && startScrim.visibility == View.VISIBLE) {
            closeStart()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    // -------------------------------------------------------------------------------- UI build

    private fun buildUi(): View {
        val root = FrameLayout(this)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x22000000) // slight dim so icon labels stay readable
        }

        desktop = DesktopGrid(this, dp(96), dp(104)).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnTouchListener { _, ev ->
                lastTouchX = ev.x
                lastTouchY = ev.y
                false
            }
            setOnLongClickListener { showDesktopMenu(); true }
            setOnContextClickListener { showDesktopMenu(); true }
        }
        column.addView(desktop, LinearLayout.LayoutParams(MATCH, 0, 1f))
        column.addView(buildTaskbar(), LinearLayout.LayoutParams(MATCH, taskbarHeight))
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        startScrim = buildStartMenu()
        root.addView(startScrim, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            bottomMargin = taskbarHeight // keep the taskbar (and Start button) reachable
        })

        contextAnchor = View(this)
        root.addView(contextAnchor, FrameLayout.LayoutParams(1, 1))

        return root
    }

    private fun buildTaskbar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(TASKBAR_BG)
            setPadding(dp(8), 0, 0, 0)
        }

        // Start button
        val start = StartButton(this).apply {
            background = pressBg(10)
            setOnClickListener { toggleStart() }
        }
        bar.addView(start, LinearLayout.LayoutParams(dp(44), dp(44)))

        // Pinned + recently opened apps
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        taskbarApps = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        scroll.addView(taskbarApps, FrameLayout.LayoutParams(WRAP, MATCH))
        bar.addView(scroll, LinearLayout.LayoutParams(0, MATCH, 1f).apply { leftMargin = dp(8) })

        // System tray
        netText = trayText("…") { openSettings(Settings.ACTION_WIFI_SETTINGS) }
        batteryText = trayText("🔋") { openSettings(Intent.ACTION_POWER_USAGE_SUMMARY) }
        val gear = trayText("⚙") { openSettings(Settings.ACTION_SETTINGS) }
        bar.addView(netText, LinearLayout.LayoutParams(WRAP, MATCH))
        bar.addView(batteryText, LinearLayout.LayoutParams(WRAP, MATCH))
        bar.addView(gear, LinearLayout.LayoutParams(WRAP, MATCH))

        val clockColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setPadding(dp(8), 0, dp(10), 0)
        }
        clockColumn.addView(TextClock(this).apply {
            format12Hour = "h:mm a"
            format24Hour = "HH:mm"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.END
        })
        clockColumn.addView(TextClock(this).apply {
            format12Hour = "EEE, MMM d"
            format24Hour = "EEE, MMM d"
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 11f
            gravity = Gravity.END
        })
        bar.addView(clockColumn, LinearLayout.LayoutParams(WRAP, MATCH))

        // "Show desktop" sliver on the far right, like Windows / DeX
        val showDesktop = View(this).apply {
            setBackgroundColor(0x55FFFFFF)
            setOnClickListener { goHome() }
        }
        bar.addView(showDesktop, LinearLayout.LayoutParams(dp(6), MATCH))

        return bar
    }

    private fun buildStartMenu(): FrameLayout {
        val scrim = FrameLayout(this).apply {
            visibility = View.GONE
            setOnClickListener { closeStart() }
        }

        val dm = resources.displayMetrics
        val panelW = minOf(dp(440), dm.widthPixels - dp(16))
        val panelH = minOf(dp(580), (dm.heightPixels * 0.72f).toInt())

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(PANEL_BG)
            }
            setPadding(dp(16), dp(16), dp(16), dp(12))
            elevation = dp(16).toFloat()
            isClickable = true // swallow taps so they don't close the menu
        }

        searchBox = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            isSingleLine = true
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0x26FFFFFF)
            }
            setPadding(dp(16), 0, dp(16), 0)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    filterApps(s?.toString() ?: "")
                }
            })
        }
        panel.addView(searchBox, LinearLayout.LayoutParams(MATCH, dp(44)))

        panel.addView(TextView(this).apply {
            text = "All apps"
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 12f
            setPadding(dp(4), dp(14), 0, dp(6))
        })

        appAdapter = AppAdapter()
        val grid = GridView(this).apply {
            numColumns = if (panelW < dp(380)) 3 else 4
            verticalSpacing = dp(6)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            adapter = appAdapter
            setOnItemClickListener { _, _, position, _ ->
                launchApp(appAdapter.getItem(position).pkg)
                closeStart()
            }
            setOnItemLongClickListener { _, view, position, _ ->
                showAppMenu(view, appAdapter.getItem(position), true)
                true
            }
        }
        panel.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        footer.addView(footerButton("⚙  Settings") { openSettings(Settings.ACTION_SETTINGS) })
        footer.addView(footerButton("🖥  Display") { openSettings(Settings.ACTION_DISPLAY_SETTINGS) })
        footer.addView(footerButton("🖼  Wallpaper") { pickWallpaper() })
        panel.addView(footer, LinearLayout.LayoutParams(MATCH, WRAP))

        scrim.addView(panel, FrameLayout.LayoutParams(panelW, panelH).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            leftMargin = dp(8)
            bottomMargin = dp(8)
        })
        return scrim
    }

    // ---------------------------------------------------------------------------- start menu

    private fun toggleStart() {
        if (startScrim.visibility == View.VISIBLE) closeStart() else openStart()
    }

    private fun openStart() {
        searchBox.setText("")
        filterApps("")
        startScrim.animate().cancel()
        startScrim.visibility = View.VISIBLE
        startScrim.alpha = 0f
        startScrim.animate().alpha(1f).setDuration(120).start()
        // With a physical keyboard attached, typing should search immediately.
        if (resources.configuration.keyboard != Configuration.KEYBOARD_NOKEYS) {
            searchBox.requestFocus()
        }
    }

    private fun closeStart() {
        if (!::startScrim.isInitialized || startScrim.visibility != View.VISIBLE) return
        startScrim.animate().cancel()
        hideKeyboard()
        startScrim.visibility = View.GONE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
    }

    private fun filterApps(query: String) {
        val q = query.trim()
        appAdapter.items = if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
        appAdapter.notifyDataSetChanged()
    }

    // ---------------------------------------------------------------------- desktop & taskbar

    private fun refreshDesktop() {
        desktop.removeAllViews()
        for (pkg in getList(KEY_DESKTOP)) {
            val app = appsByPkg[pkg] ?: continue
            val cell = makeIconCell(48, 12f)
            bindIconCell(cell, app)
            cell.setOnClickListener { launchApp(app.pkg) }
            cell.setOnLongClickListener { showAppMenu(it, app, false); true }
            cell.setOnContextClickListener { showAppMenu(it, app, false); true }
            desktop.addView(cell)
        }
    }

    private fun refreshTaskbar() {
        taskbarApps.removeAllViews()
        val shown = LinkedHashSet<String>(getList(KEY_TASKBAR))
        shown.addAll(recent)
        for (pkg in shown) {
            val app = appsByPkg[pkg] ?: continue
            taskbarApps.addView(
                makeTaskbarItem(app),
                LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(2) }
            )
        }
    }

    private fun makeTaskbarItem(app: AppInfo): View {
        val active = recent.contains(app.pkg)
        val frame = FrameLayout(this).apply { background = pressBg(10) }
        frame.addView(
            ImageView(this).apply { setImageDrawable(app.iconCopy()) },
            FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER)
        )
        if (active) {
            val indicator = View(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(2).toFloat()
                    setColor(ACCENT)
                }
            }
            frame.addView(
                indicator,
                FrameLayout.LayoutParams(dp(14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                    bottomMargin = dp(2)
                }
            )
        }
        frame.setOnClickListener { closeStart(); launchApp(app.pkg) }
        frame.setOnLongClickListener { showAppMenu(it, app, false); true }
        frame.setOnContextClickListener { showAppMenu(it, app, false); true }
        return frame
    }

    private fun refreshAll() {
        refreshDesktop()
        refreshTaskbar()
        filterApps(if (::searchBox.isInitialized) searchBox.text.toString() else "")
    }

    // ------------------------------------------------------------------------------- menus

    private fun showAppMenu(anchor: View, app: AppInfo, fromStart: Boolean) {
        val onDesktop = getList(KEY_DESKTOP).contains(app.pkg)
        val onTaskbar = getList(KEY_TASKBAR).contains(app.pkg)
        val popup = PopupMenu(this, anchor)
        val m = popup.menu
        m.add(Menu.NONE, 1, Menu.NONE, "Open")
        m.add(Menu.NONE, 2, Menu.NONE, if (onTaskbar) "Unpin from taskbar" else "Pin to taskbar")
        m.add(Menu.NONE, 3, Menu.NONE, if (onDesktop) "Remove from desktop" else "Add to desktop")
        if (recent.contains(app.pkg)) m.add(Menu.NONE, 4, Menu.NONE, "Clear running indicator")
        m.add(Menu.NONE, 5, Menu.NONE, "App info")
        m.add(Menu.NONE, 6, Menu.NONE, "Uninstall")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    launchApp(app.pkg)
                    if (fromStart) closeStart()
                }
                2 -> toggleIn(KEY_TASKBAR, app.pkg)
                3 -> toggleIn(KEY_DESKTOP, app.pkg)
                4 -> {
                    recent.remove(app.pkg)
                    refreshTaskbar()
                }
                5 -> startInWindow(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                )
                6 -> startInWindow(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            }
            true
        }
        popup.show()
    }

    private fun showDesktopMenu() {
        contextAnchor.translationX = lastTouchX
        contextAnchor.translationY = lastTouchY
        val popup = PopupMenu(this, contextAnchor)
        val m = popup.menu
        m.add(Menu.NONE, 1, Menu.NONE, "Open start menu")
        val windowedItem = m.add(Menu.NONE, 2, Menu.NONE, "Open apps in windows")
        windowedItem.isCheckable = true
        windowedItem.isChecked = prefs.getBoolean(KEY_WINDOWED, true)
        m.add(Menu.NONE, 3, Menu.NONE, "Change wallpaper")
        m.add(Menu.NONE, 4, Menu.NONE, "Display settings")
        m.add(Menu.NONE, 5, Menu.NONE, "Reset desktop icons")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openStart()
                2 -> prefs.edit().putBoolean(KEY_WINDOWED, !prefs.getBoolean(KEY_WINDOWED, true)).apply()
                3 -> pickWallpaper()
                4 -> openSettings(Settings.ACTION_DISPLAY_SETTINGS)
                5 -> {
                    prefs.edit().remove(KEY_DESKTOP).remove(KEY_TASKBAR).apply()
                    ensureDefaults()
                    refreshAll()
                }
            }
            true
        }
        popup.show()
    }

    // ----------------------------------------------------------------------------- launching

    private fun launchApp(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("Can't open that app")
            return
        }
        if (startInWindow(intent)) {
            recent.remove(pkg)
            recent.add(pkg)
            while (recent.size > 6) recent.removeAt(0)
            refreshTaskbar()
        }
    }

    /** Starts [intent], as a freeform window if the device supports it and windowing is enabled. */
    private fun startInWindow(intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            if (prefs.getBoolean(KEY_WINDOWED, true)) {
                val options = ActivityOptions.makeBasic()
                options.setLaunchBounds(nextWindowBounds())
                startActivity(intent, options.toBundle())
            } else {
                startActivity(intent)
            }
            true
        } catch (e: Exception) {
            toast("Can't open that")
            false
        }
    }

    private fun nextWindowBounds(): Rect {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels - taskbarHeight
        val phone = resources.configuration.screenWidthDp < 600
        val wFactor = if (phone) 0.94f else 0.62f
        val hFactor = if (phone) 0.85f else 0.78f
        val ww = (w * wFactor).toInt()
        val wh = (h * hFactor).toInt()
        val step = dp(36)
        val n = windowCounter++ % 6
        val left = if (phone) (w - ww) / 2 else dp(90) + n * step
        val top = dp(24) + n * step
        val l = maxOf(0, minOf(left, w - ww))
        val t = maxOf(0, minOf(top, h - wh))
        return Rect(l, t, l + ww, t + wh)
    }

    private fun goHome() {
        closeStart()
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun openSettings(action: String) {
        closeStart()
        startInWindow(Intent(action))
    }

    private fun pickWallpaper() {
        closeStart()
        try {
            startActivity(
                Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Select wallpaper")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            openSettings(Settings.ACTION_DISPLAY_SETTINGS)
        }
    }

    // ------------------------------------------------------------------------------- app data

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = list
                appsByPkg = list.associateBy { it.pkg }
                ensureDefaults()
                refreshAll()
            }
        }.start()
    }

    /** First run: fill the desktop and taskbar with the phone's default browser, dialer, camera, etc. */
    private fun ensureDefaults() {
        if (prefs.contains(KEY_DESKTOP)) return
        val defaults = defaultPackages().filter { appsByPkg.containsKey(it) }
        saveList(KEY_DESKTOP, defaults.take(12))
        saveList(KEY_TASKBAR, defaults.take(4))
    }

    private fun defaultPackages(): List<String> {
        val result = LinkedHashSet<String>()
        fun add(intent: Intent) {
            val pkg = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName
            if (pkg != null && pkg != "android" && pkg != packageName) result.add(pkg)
        }
        add(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")))
        add(Intent(Intent.ACTION_DIAL))
        add(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        add(Intent(Settings.ACTION_SETTINGS))
        for (category in listOf(
            Intent.CATEGORY_APP_MESSAGING,
            Intent.CATEGORY_APP_GALLERY,
            Intent.CATEGORY_APP_EMAIL,
            Intent.CATEGORY_APP_CALCULATOR,
            Intent.CATEGORY_APP_MUSIC,
            Intent.CATEGORY_APP_MAPS,
            Intent.CATEGORY_APP_CALENDAR,
            Intent.CATEGORY_APP_CONTACTS
        )) {
            add(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, category))
        }
        return result.toList()
    }

    private fun getList(key: String): MutableList<String> =
        (prefs.getString(key, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun saveList(key: String, list: List<String>) {
        prefs.edit().putString(key, list.joinToString(",")).apply()
    }

    private fun toggleIn(key: String, pkg: String) {
        val list = getList(key)
        if (!list.remove(pkg)) list.add(pkg)
        saveList(key, list)
        refreshAll()
    }

    // --------------------------------------------------------------------------- system tray

    private fun connectivity() = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            runOnUiThread { updateNet(caps) }
        }

        override fun onLost(network: Network) {
            runOnUiThread { updateNet(null) }
        }
    }

    private fun updateNet(caps: NetworkCapabilities?) {
        val (icon, label) = when {
            caps == null -> "✈" to "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "📶" to "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "📱" to "Mobile"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "🔌" to "Ethernet"
            else -> "🌐" to "Online"
        }
        netText.text = if (compact) icon else "$icon $label"
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
            batteryText.text = (if (charging) "⚡" else "🔋") + " $pct%"
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            loadApps()
        }
    }

    private fun registerSystemReceiver(receiver: BroadcastReceiver, filter: IntentFilter): Intent? =
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }

    // ---------------------------------------------------------------------------------- views

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun pressBg(radiusDp: Int): Drawable {
        val highlight = GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(0x33FFFFFF)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), highlight)
            addState(intArrayOf(android.R.attr.state_hovered), highlight)
            addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
        }
    }

    private fun AppInfo.iconCopy(): Drawable = icon.constantState?.newDrawable(resources)?.mutate() ?: icon

    private fun makeIconCell(iconDp: Int, textSp: Float): LinearLayout {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(8), dp(4), dp(4))
            background = pressBg(10)
        }
        cell.addView(
            ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER },
            LinearLayout.LayoutParams(dp(iconDp), dp(iconDp))
        )
        cell.addView(
            TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = textSp
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setShadowLayer(4f, 0f, 1f, 0xAA000000.toInt())
            },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) }
        )
        return cell
    }

    private fun bindIconCell(cell: View, app: AppInfo) {
        val ll = cell as LinearLayout
        (ll.getChildAt(0) as ImageView).setImageDrawable(app.iconCopy())
        (ll.getChildAt(1) as TextView).text = app.label
    }

    private fun trayText(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 12f
        gravity = Gravity.CENTER
        setPadding(dp(8), 0, dp(8), 0)
        background = pressBg(8)
        setOnClickListener { onClick() }
    }

    private fun footerButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 12f
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = pressBg(8)
        setOnClickListener { onClick() }
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<AppInfo> = emptyList()

        override fun getCount() = items.size
        override fun getItem(position: Int): AppInfo = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val app = items[position]
            val cell = convertView ?: makeIconCell(44, 11f)
            bindIconCell(cell, app)
            cell.setOnContextClickListener { showAppMenu(it, app, true); true }
            return cell
        }
    }
}

/** Lays children out in columns, top to bottom then left to right, like a desktop. */
private class DesktopGrid(context: Context, private val cellW: Int, private val cellH: Int) :
    ViewGroup(context) {

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val cw = MeasureSpec.makeMeasureSpec(cellW, MeasureSpec.EXACTLY)
        val ch = MeasureSpec.makeMeasureSpec(cellH, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(cw, ch)
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val availableH = (b - t) - paddingTop - paddingBottom
        val rows = maxOf(1, availableH / cellH)
        for (i in 0 until childCount) {
            val col = i / rows
            val row = i % rows
            val x = paddingLeft + col * cellW
            val y = paddingTop + row * cellH
            getChildAt(i).layout(x, y, x + cellW, y + cellH)
        }
    }
}

/** The 2x2 "start" tile in the taskbar. */
private class StartButton(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val total = minOf(width, height) * 0.5f
        val gap = total * 0.12f
        val cell = (total - gap) / 2f
        val left = (width - total) / 2f
        val top = (height - total) / 2f
        val radius = cell * 0.2f
        for (row in 0..1) {
            for (col in 0..1) {
                paint.color = if (row == 0 && col == 0) ACCENT else Color.WHITE
                val x = left + col * (cell + gap)
                val y = top + row * (cell + gap)
                canvas.drawRoundRect(RectF(x, y, x + cell, y + cell), radius, radius, paint)
            }
        }
    }
}
