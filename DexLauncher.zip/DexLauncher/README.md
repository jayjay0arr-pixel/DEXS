# DeX Launcher

A desktop-style Android launcher inspired by Samsung DeX: wallpaper desktop with icons, a taskbar with a Start button, pinned and recently opened apps, a system tray (network, battery, settings, clock), a searchable Start menu, and apps opened as freeform windows.

## Build the APK

**Option A: Android Studio**
1. Open this folder in Android Studio (File > Open).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

**Option B: GitHub Actions (no PC needed)**
1. Create a GitHub repository and upload this whole folder (including the hidden `.github` folder).
2. Open the Actions tab, run "Build APK", and download `DexLauncher-debug-apk` when it finishes.

## Install and set as home

1. Copy the APK to the phone and install it (allow "install unknown apps" for your file manager or browser).
2. Press Home, choose "DeX Launcher", and pick "Always" (or Settings > Apps > Default apps > Home app).

## Getting real windows

Opening apps in resizable windows needs freeform window support, which Android hides behind developer options:

1. Settings > About phone > Software information, tap Build number 7 times.
2. Settings > Developer options, turn on:
   - Enable freeform windows
   - Force activities to be resizable
   - Force desktop mode (applies to an external display)
3. Reboot.

If your phone does not support freeform windows, apps open full screen as normal. You can turn windowing off by right-clicking or long-pressing the desktop and unchecking "Open apps in windows".

## Controls

- Tap an icon to open. Long-press or right-click for pin, unpin, app info and uninstall.
- Windows/Meta key opens the Start menu on a hardware keyboard. Esc closes it.
- The thin strip at the far right of the taskbar returns to the desktop.
- Long-press or right-click on empty desktop for wallpaper, display settings and reset.

## Limits

- The blue underline on the taskbar marks apps you opened from this launcher. Android does not let a normal app list other apps' running windows, so the mark stays until you clear it from the app's menu.
- This replaces your home screen; it does not replace Samsung's own DeX shell when you plug into a monitor.
